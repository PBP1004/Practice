x=1
y=2
print("Sum of x and y is =")
print(x+y)
